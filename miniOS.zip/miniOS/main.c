#include "os.h"

volatile int delay_cnt;
void qmdelay()
{
	delay_cnt=0;
	for(int i=0;i<100;i++){
		delay_cnt++;
	}
}
void err_func()
{
	int a=10;
}
int cacu(int n1,int n2,int n3,int n4,int n5,int n6,int n7,int n8,int n9,int n10,int n11,int n12,int n13,int n14,int n15)
{
	int res;
	res = n1 + n2 + n3 + n4 + n5 + n6 + n7 + n8 + n9 + n10 + n11 + n12 + n13 + n14 + n15;
	return res;
}
void complex_test()
{
	int n1=1;
	int n2=2;
	int n3=3;
	int n4=4;
	int n5=5;
	int n6=6;
	int n7=7;
	int n8=8;
	int n9=9;
	int n10=10;
	int n11=11;
	int n12=12;
	int n13=13;
	int n14=14;
	int n15=15;
	int res = cacu(n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12,n13,n14,n15);
	if (res != 120) {
		err_func();
	}
}
int g_res1;
static void task1(void *param)
{
	(void)param;
	while(1) {
		g_res1++;
		complex_test();
		qmdelay();
	}
}
int g_res2;
static void task2(void *param)
{
	(void)param;
	while(1) {
		g_res2++;
		complex_test();
		qmdelay();
	}
}
int g_res3;
static void task3(void *param)
{
	(void)param;
	while(1) {
		g_res3++;
		complex_test();
		qmdelay();
	}
}
int g_res4;
static void task4(void *param)
{
	(void)param;
	while(1) {
		g_res4++;
		complex_test();
		qmdelay();
	}
}

void enableDualTimer0(unsigned int period)
{
	volatile uint32* DualTimer0 = (uint32*)0xE0101000;
	*(DualTimer0+0x2) = 0x0;	// Disable timer
	*(DualTimer0+0x0) = period;
//	*(DualTimer0+0x2) = 0xe3;	// Enable timer, ons-shot mode, enable interrupts, 32-bit counter
	*(DualTimer0+0x2) = 0xe2;	// Enable timer, periodic mode, enable interrupts, 32-bit counter
}
void enableDualTimer1(unsigned int period)
{
	volatile uint32* DualTimer1 = (uint32*)0xE0101020;
	*(DualTimer1+0x2) = 0x0;	// Disable timer
	*(DualTimer1+0x0) = period;
//	*(DualTimer1+0x2) = 0xe3;	// Enable timer, ons-shot mode, enable interrupts, 32-bit counter
	*(DualTimer1+0x2) = 0xe2;	// Enable timer, periodic mode, enable interrupts, 32-bit counter
}
int main(void)
{
  xTaskCreate(task1, "task1", 200, NULL, 1, NULL);
  xTaskCreate(task2, "task2", 200, NULL, 1, NULL);
  xTaskCreate(task3, "task3", 200, NULL, 1, NULL);
  xTaskCreate(task4, "task4", 200, NULL, 1, NULL);

  gic_setup();

  enableDualTimer0(0x2000);
  enableDualTimer1(0x4000);

  vTaskStartScheduler();
  while(1);
  return 0;
}

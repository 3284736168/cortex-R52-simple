/*
 * os_types.h
 *
 *  Created on: 2024年8月18日
 *      Author: qm
 */

#ifndef FREERTOS_OS_TYPES_H_
#define FREERTOS_OS_TYPES_H_
#include "os_config.h"

#define configUSE_TASK_NOTIFICATIONS 1
#define portBYTE_ALIGNMENT			8
#define portBYTE_ALIGNMENT_MASK ( 0x0007 )
#define portPOINTER_SIZE_TYPE uint32_t

typedef long BaseType_t;
typedef void (*TaskFunction_t)( void * );
typedef unsigned long UBaseType_t;
typedef void * TaskHandle_t;

typedef unsigned int uint32;
typedef unsigned short uint16;
typedef unsigned char uint8;

typedef uint32 uint32_t;
typedef uint16 uint16_t;
typedef uint8 uint8_t;

typedef __SIZE_TYPE__ size_t;

typedef uint32 TickType_t;
#define NULL ((void *)0)
#define portCHAR		char
#define portFLOAT		float
#define portDOUBLE		double
#define portLONG		long
#define portSHORT		short

#define pdFALSE			( ( BaseType_t ) 0 )
#define pdTRUE			( ( BaseType_t ) 1 )

#define pdPASS			( pdTRUE )
#define pdFAIL			( pdFALSE )

#define configSUPPORT_DYNAMIC_ALLOCATION 1


#define tskIDLE_PRIORITY			( ( UBaseType_t ) 0U )
#define portPRIVILEGE_BIT ( ( UBaseType_t ) 0x00 )
static TaskHandle_t xIdleTaskHandle					= NULL;
#define traceMALLOC( pvAddress, uiSize )

#define taskNOT_WAITING_NOTIFICATION	( ( uint8_t ) 0 )
#define taskWAITING_NOTIFICATION		( ( uint8_t ) 1 )
#define taskNOTIFICATION_RECEIVED		( ( uint8_t ) 2 )

#define portENTER_CRITICAL()		vPortEnterCritical()
#define taskENTER_CRITICAL()		portENTER_CRITICAL()

#define configASSERT( x )
#define listSET_LIST_ITEM_OWNER( pxListItem, pxOwner )		( ( pxListItem )->pvOwner = ( void * ) ( pxOwner ) )
#define listSET_LIST_ITEM_VALUE( pxListItem, xValue )	( ( pxListItem )->xItemValue = ( xValue ) )

#define portINITIAL_SPSR				( ( StackType_t ) 0x1f )
#define portNO_CRITICAL_SECTION_NESTING	( ( StackType_t ) 0 )

#define taskEXIT_CRITICAL()			portEXIT_CRITICAL()
#define portEXIT_CRITICAL()			vPortExitCritical();

#define portNO_CRITICAL_NESTING		( ( uint32_t ) 0 )

#define portYIELD()					__asm volatile ( "SWI 0" )
#define portYIELD_WITHIN_API portYIELD
#define taskYIELD_IF_USING_PREEMPTION() portYIELD_WITHIN_API()

#define portYIELD_WITHIN_API portYIELD
#define taskYIELD_IF_USING_PREEMPTION() portYIELD_WITHIN_API()

struct xLIST_ITEM
{
	TickType_t xItemValue;			/*< The value being listed.  In most cases this is used to sort the list in descending order. */
	struct xLIST_ITEM* pxNext;		/*< Pointer to the next ListItem_t in the list. */
	struct xLIST_ITEM* pxPrevious;	/*< Pointer to the previous ListItem_t in the list. */
	void * pvOwner;										/*< Pointer to the object (normally a TCB) that contains the list item.  There is therefore a two way link between the object containing the list item and the list item itself. */
	void * pvContainer;				/*< Pointer to the list in which this list item is placed (if any). */
};
typedef struct xLIST_ITEM ListItem_t;					/* For some reason lint wants this as two separate definitions. */


#define portSTACK_TYPE	unsigned portLONG
typedef portSTACK_TYPE StackType_t;
typedef struct tskTaskControlBlock
{
	volatile StackType_t *pxTopOfStack;	/*< Points to the location of the last item placed on the tasks stack.  THIS MUST BE THE FIRST MEMBER OF THE TCB STRUCT. */

	ListItem_t			xStateListItem;	/*< The list that the state list item of a task is reference from denotes the state of that task (Ready, Blocked, Suspended ). */
	ListItem_t			xEventListItem;		/*< Used to reference a task from an event list. */
	UBaseType_t			uxPriority;			/*< The priority of the task.  0 is the lowest priority. */
	StackType_t			*pxStack;			/*< Points to the start of the stack. */
	char				pcTaskName[ configMAX_TASK_NAME_LEN ];/*< Descriptive name given to the task when created.  Facilitates debugging only. */ /*lint !e971 Unqualified char types are allowed for strings and single characters only. */

	#if( configUSE_TASK_NOTIFICATIONS == 1 )
		volatile uint32_t ulNotifiedValue;
		volatile uint8_t ucNotifyState;
	#endif
} tskTCB;

typedef tskTCB TCB_t;

typedef struct xMEMORY_REGION
{
	void *pvBaseAddress;
	uint32_t ulLengthInBytes;
	uint32_t ulParameters;
} MemoryRegion_t;


struct xMINI_LIST_ITEM
{
	TickType_t xItemValue;
	struct xLIST_ITEM * pxNext;
	struct xLIST_ITEM * pxPrevious;
};
typedef struct xMINI_LIST_ITEM MiniListItem_t;

typedef struct xLIST
{
	UBaseType_t uxNumberOfItems;
	ListItem_t *  pxIndex;			/*< Used to walk through the list.  Points to the last item returned by a call to listGET_OWNER_OF_NEXT_ENTRY (). */
	MiniListItem_t xListEnd;							/*< List item that contains the maximum possible item value meaning it is always at the end of the list and is therefore used as a marker. */

} List_t;
#endif /* FREERTOS_OS_TYPES_H_ */

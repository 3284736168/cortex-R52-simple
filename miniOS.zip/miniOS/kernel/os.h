/*
 * os.h
 *
 *  Created on: 2024年8月18日
 *      Author: qm
 */

#ifndef FREERTOS_OS_H_
#define FREERTOS_OS_H_

#include "os_types.h"

#define portDISABLE_INTERRUPTS()											\
	__asm volatile (														\
		"STMDB	SP!, {R0}		\n\t"	/* Push R0.						*/	\
		"MRS	R0, CPSR		\n\t"	/* Get CPSR.					*/	\
		"ORR	R0, R0, #0xC0	\n\t"	/* Disable IRQ, FIQ.			*/	\
		"MSR	CPSR, R0		\n\t"	/* Write back modified value.	*/	\
		"LDMIA	SP!, {R0}			" )	/* Pop R0.						*/

#define portENABLE_INTERRUPTS()												\
	__asm volatile (														\
		"STMDB	SP!, {R0}		\n\t"	/* Push R0.						*/	\
		"MRS	R0, CPSR		\n\t"	/* Get CPSR.					*/	\
		"BIC	R0, R0, #0xC0	\n\t"	/* Enable IRQ, FIQ.				*/	\
		"MSR	CPSR, R0		\n\t"	/* Write back modified value.	*/	\
		"LDMIA	SP!, {R0}			" )	/* Pop R0.						*/


BaseType_t xTaskCreate(	TaskFunction_t pxTaskCode,
						const char * const pcName,
						const uint16_t usStackDepth,
						void * const pvParameters,
						UBaseType_t uxPriority,
						TaskHandle_t * const pxCreatedTask );

void vTaskStartScheduler( void );
static volatile UBaseType_t uxSchedulerSuspended	= ( UBaseType_t ) pdFALSE;
void vTaskSuspendAll( void );
void *pvPortMalloc( size_t xSize );
void vPortYieldProcessor( void ) __attribute__((interrupt("SWI"), naked));
void vPortFree( void *pv );
void prvInitialiseNewTask( 	TaskFunction_t pxTaskCode,
							const char * const pcName,
							const uint32_t ulStackDepth,
							void * const pvParameters,
							UBaseType_t uxPriority,
							TaskHandle_t * const pxCreatedTask,
							TCB_t *pxNewTCB,
							const MemoryRegion_t * const xRegions );
void prvAddNewTaskToReadyList( TCB_t *pxNewTCB );
BaseType_t xPortStartScheduler( void );
void vPortEnterCritical( void );
StackType_t *pxPortInitialiseStack( StackType_t *pxTopOfStack, TaskFunction_t pxCode, void *pvParameters );
void prvInitialiseTaskLists( void );
void vListInsertEnd( List_t * const pxList, ListItem_t * const pxNewListItem );
void vPortExitCritical( void );
void prvSetupTimerInterrupt( void );
void vPortISRStartFirstTask( void );
void vListInitialise( List_t * const pxList );
void vPortSwitchContext( void ) __attribute__((naked));
void vTaskSwitchContext( void );
uint32_t gic_get_irq(void);
void gic_ack_irq(uint32_t irq_id);
void DualTimer0IRQhandler(void);
void gic_setup(void);
#endif /* FREERTOS_OS_H_ */
